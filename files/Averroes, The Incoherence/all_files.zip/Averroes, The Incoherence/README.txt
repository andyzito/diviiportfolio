Averroes, also known as Ibn Rushd, was one of the greatest ancient Islamic philosophers. In this course we dissected several of his writings and dealt with many topics in theology, philosophy of science, and metaphysics. Much time was also devoted to the disagreements between Averroes and another great Islamic philosopher, Al-Ghazali.

Final Paper:
A paper discussing cause and effect in Averroes, Ghazali, and Hume. Includes a reference work, "On the Natural Sciences" (a discussion from Averroes' Incoherence of the Incoherence).

midterm_paper.docx:
A discussion of space and time in Averroes' The Incoherence.
