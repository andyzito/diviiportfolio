I took this course at UMass. I am unable to locate the official	course description. It was a pretty standard language learning course. I did not enjoy it very much due to what I felt was an unfairly large workload and a great deal of inflexibility on the part of the instructors.

NOTE: Unfortunately the majority of my work in this class was handwritten, either freehand essays or problem sets in the workbook. These works have since been lost to the winds of time.

Final Presentation:
My final presentation slideshow and script. I presented an account of the life of a fictional character named Brian.

final_skit.docx:
A collaborative final project, in which I worked with two fellow students to write and perform a short skit in Mandarin. We played a family making an important life decision and falling apart in the process.

journal.txt:
A short journal assignment about a girl who wants to run a restaurant when she grows up.