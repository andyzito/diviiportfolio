Assignment 1:
....Prompt: Submit an iPython notebook containing original Python code for any purpose.
....Submitted: A short number guessing game.

Assignment 2:
....Prompt: Submit an iPython notebook that reads and prints information about your data.
....Submitted: A program that reads and graphs data about gun violence.

Assignment 3:
....Prompt: Submit an iPython notebook that produces meaningful analysis and/or visualizations of your data.
....Submitted: A program that reads and graphs data about the ability of Hawaiians to speak English.

Assignment 4:
....Prompt: Submit an iPython notebook that conducts a simulation and analyzes and/or visualizes the data produced by the simulation.
....Submitted: An early version of a program that attempts to evolve the letter frequencies of English.

Final Project:
An extension of the program from Assignment 4, in which random string generators mutate the letter frequencies they use, and attempt to evolve the actual letter frequencies of english.