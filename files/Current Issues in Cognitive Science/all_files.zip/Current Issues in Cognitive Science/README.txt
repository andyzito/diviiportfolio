While the majority of my work in this course involved in class discussions, there are several pieces I can present here.

There are three folders here which represent three readings selected from our course, as well as my responses to them.

final_paper.pdf:
My final paper, regarding the hard problem of consciousness.