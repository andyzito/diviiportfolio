Unfortunately, the prompts for the assignments were removed from Moodle prior to the creation of this portfolio. I have left the assignments here, as they still serve to demonstrate my accomplishments in the course.

Assignments: Various homework assignments (Assignments 1 and 2 were handwritten, and are not available at this time)

phonology_group_project.pdf and phonology_group_presentation_write_up.pdf are the two parts of our final (group) project, in which we studied the phonology of a language (French in our case)