﻿chinese_family_reunion.docx: A story about a family reunion
group_presentation.pdf: A skit in which we played college students looking for jobs
一胎制.pptx: A presentation about China's one child policy
寒假.pdf: A reflection on winter break
川普.pptx: A presentation about presidential candidate Donald Trump and his plan to build a wall between the United States and Mexico
故事draft1.pdf: A fable about a girl and boy who encounter a dragon
美国人口增多.pptx: Should America have a one child policy?