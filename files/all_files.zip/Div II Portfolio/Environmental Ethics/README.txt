This course was exactly what it says on the tin. We started the semester focusing largely on individual animal rights, and broadened out to encompass more abstract entities -- for example, do entire biosystems have moral worth?

paper_1.docx:
How we draw moral lines. What is moral and what is amoral? Specifically how this affects our treatment of and consideration of animals.

paper_2.docx:
Atomism vs. Holism in environmental ethics. Should we value individuals or entire ecosystems?

final_paper.pdf:
How (and if) we can define what "wilderness" is.