The majority of this course was spent studying the Socratic/Platonic dialogues. We spent about a week discussing each dialogue in class, using each one as a window into the philosophy of the time. Some literary analysis of the dialogues was also conducted.

final_paper.pdf:
Final paper for the course, in which I discuss continence/incontinence in Aristotle's Nichomachean Ethics.

paper_1.pdf:
A discussion of courage in the Platonic dialogues Laches and Protagoras.

paper_2.pdf:
A critique of the Platonic dialogue Lysis, a less well known dialogue that is curiously nonsensical.

platonic_dialogue.pdf:
A "Platonic dialogue" of my own creation, set after Euthyphro and The Apology.